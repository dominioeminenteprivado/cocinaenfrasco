import{l as t}from"./2c1ab0fe.CM6f73yn.js";function e(e){return function(e){return e&&"object"==typeof e&&e instanceof t}(e)?e.value:e}export{e as r};
