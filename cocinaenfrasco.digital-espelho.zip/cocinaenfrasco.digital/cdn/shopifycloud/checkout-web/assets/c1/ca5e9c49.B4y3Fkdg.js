import{u as r}from"./4b4bc88f.C1a6xVCn.js";import{P as o}from"./164ad2e3.DEmmL7YI.js";function s(){return r(o)}export{s as u};
